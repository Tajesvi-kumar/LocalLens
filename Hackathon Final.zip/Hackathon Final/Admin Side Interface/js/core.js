// Core functionality for LocalLens application

// Dark mode toggle with sun/moon icon and preference
const darkModeToggle = document.getElementById('darkModeToggle');
const darkModeIcon = document.getElementById('darkModeIcon');

function setDarkMode(enabled) {
  document.body.classList.toggle('dark-mode', enabled);
  darkModeIcon.textContent = enabled ? '☀️' : '🌙';
  localStorage.setItem('darkMode', enabled ? '1' : '0');
}

darkModeToggle.addEventListener('click', function() {
  setDarkMode(!document.body.classList.contains('dark-mode'));
});

// Load preference on start
document.addEventListener('DOMContentLoaded', function() {
  const pref = localStorage.getItem('darkMode');
  if (pref === '1') setDarkMode(true);
  else setDarkMode(false);
});

// UI switching functionality
function showUserUI() {
  document.getElementById('user-section').classList.remove('hidden');
  document.getElementById('admin-section').classList.add('hidden');
  document.getElementById('admin-sidebar').classList.add('hidden');
  document.getElementById('userTab').classList.add('active');
  document.getElementById('adminTab').classList.remove('active');
}

function showAdminUI() {
  document.getElementById('user-section').classList.add('hidden');
  document.getElementById('admin-section').classList.remove('hidden');
  document.getElementById('admin-sidebar').classList.remove('hidden');
  document.getElementById('userTab').classList.remove('active');
  document.getElementById('adminTab').classList.add('active');
}

// Tab switching
document.getElementById('userTab').addEventListener('click', showUserUI);
document.getElementById('adminTab').addEventListener('click', showAdminUI);

// Form validation
function validateForm(formData) {
  const errors = [];
  
  if (!formData.title || formData.title.trim().length < 3) {
    errors.push('Title must be at least 3 characters long');
  }
  
  if (!formData.description || formData.description.trim().length < 10) {
    errors.push('Description must be at least 10 characters long');
  }
  
  if (!formData.category) {
    errors.push('Please select a category');
  }
  
  if (!formData.location || formData.location.trim().length < 3) {
    errors.push('Please provide a location');
  }
  
  return errors;
}

// Show status messages
function showStatus(message, type = 'info') {
  const statusEl = document.getElementById('formStatus');
  if (!statusEl) return;
  
  statusEl.textContent = message;
  statusEl.className = `status-message status-${type}`;
  statusEl.style.display = 'block';
  
  setTimeout(() => {
    statusEl.style.display = 'none';
  }, 5000);
}

// Format date
function formatDate(date) {
  if (!date) return 'N/A';
  
  if (date.toDate) {
    date = date.toDate();
  } else if (typeof date === 'string') {
    date = new Date(date);
  }
  
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Get status color
function getStatusColor(status) {
  const colors = {
    pending: '#fef3c7',
    'in-progress': '#dbeafe',
    resolved: '#d1fae5',
    high_priority: '#fee2e2'
  };
  return colors[status] || '#f3f4f6';
}

// Get status text color
function getStatusTextColor(status) {
  const colors = {
    pending: '#92400e',
    'in-progress': '#1e40af',
    resolved: '#065f46',
    high_priority: '#991b1b'
  };
  return colors[status] || '#374151';
}

// Export functions for other modules
window.LocalLensCore = {
  showUserUI,
  showAdminUI,
  validateForm,
  showStatus,
  formatDate,
  getStatusColor,
  getStatusTextColor,
  setDarkMode
};
