// Firebase configuration and operations for LocalLens

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-analytics.js";
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import {
  getFirestore, collection, addDoc, doc, setDoc, getDoc, updateDoc,
  serverTimestamp, query, orderBy, onSnapshot, increment, getDocs
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAUguDQnqkLVb3KjKLqQ93XnepYGwObMSk",
  authDomain: "locallens-34cd0.firebaseapp.com",
  databaseURL: "https://locallens-34cd0-default-rtdb.firebaseio.com",
  projectId: "locallens-34cd0",
  storageBucket: "locallens-34cd0.firebasestorage.app",
  messagingSenderId: "603385458788",
  appId: "1:603385458788:web:bc337e0326a6c46bf16f71",
  measurementId: "G-87QF1TK1V2"
};

// Initialize Firebase
let app, analytics, auth, db;
try {
  app = initializeApp(firebaseConfig);
  analytics = getAnalytics(app);
  auth = getAuth(app);
  db = getFirestore(app);
  console.log('Firebase initialized successfully');
} catch (error) {
  console.error('Firebase initialization error:', error);
  alert('Firebase initialization failed. Please check your configuration.');
}

// Global variables
let currentUser = null;
let unsubscribe = null;
let commentUnsubs = {};

// Authentication functions
function signUp(email, password) {
  return createUserWithEmailAndPassword(auth, email, password);
}

function signIn(email, password) {
  return signInWithEmailAndPassword(auth, email, password);
}

function signOutUser() {
  return signOut(auth);
}

// User authentication state management
onAuthStateChanged(auth, (user) => {
  currentUser = user;
  const userBadge = document.getElementById("userBadge");
  const logoutBtn = document.getElementById("logoutBtn");
  const authCard = document.getElementById("authCard");
  const reportCard = document.getElementById("reportCard");

  if (user) {
    userBadge.textContent = user.email;
    authCard.classList.add("hidden");
    reportCard.classList.remove("hidden");
    logoutBtn.classList.remove("hidden");
    
    // Check if admin
    if (user.email === "admin@gmail.com") {
      document.getElementById("adminTab").style.display = "inline-block";
    } else {
      document.getElementById("adminTab").style.display = "none";
    }
    
    // Start listening for real-time updates
    startRealtimeListener();
  } else {
    authCard.classList.remove("hidden");
    reportCard.classList.add("hidden");
    logoutBtn.classList.add("hidden");
    document.getElementById("adminTab").style.display = "none";
    
    // Stop listening for updates
    if (unsubscribe) {
      unsubscribe();
      unsubscribe = null;
    }
  }
});

// Submit new issue
async function submitIssue(formData) {
  try {
    const issueData = {
      ...formData,
      createdAt: serverTimestamp(),
      status: 'pending',
      voteCount: 0,
      userId: currentUser.uid,
      userEmail: currentUser.email
    };
    
    const docRef = await addDoc(collection(db, "issues"), issueData);
    console.log("Issue submitted with ID: ", docRef.id);
    return { success: true, id: docRef.id };
  } catch (error) {
    console.error("Error submitting issue: ", error);
    return { success: false, error: error.message };
  }
}

// Update issue status
async function updateIssueStatus(issueId, status) {
  try {
    const issueRef = doc(db, "issues", issueId);
    await updateDoc(issueRef, { 
      status,
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("Error updating issue status: ", error);
    return { success: false, error: error.message };
  }
}

// Vote on issue
async function voteOnIssue(issueId) {
  try {
    const issueRef = doc(db, "issues", issueId);
    await updateDoc(issueRef, {
      voteCount: increment(1)
    });
    return { success: true };
  } catch (error) {
    console.error("Error voting on issue: ", error);
    return { success: false, error: error.message };
  }
}

// Add comment to issue
async function addComment(issueId, comment) {
  try {
    const issueRef = doc(db, "issues", issueId);
    const commentData = {
      text: comment,
      createdAt: serverTimestamp(),
      userId: currentUser.uid,
      userEmail: currentUser.email
    };
    
    // Get existing comments
    const issueDoc = await getDoc(issueRef);
    const existingData = issueDoc.data();
    const comments = existingData.comments || [];
    
    await updateDoc(issueRef, {
      comments: [...comments, commentData]
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error adding comment: ", error);
    return { success: false, error: error.message };
  }
}

// Get all issues
async function getAllIssues() {
  try {
    const q = query(collection(db, "issues"), orderBy("createdAt", "desc"));
    const querySnapshot = await getDocs(q);
    const issues = [];
    
    querySnapshot.forEach((doc) => {
      issues.push({ id: doc.id, ...doc.data() });
    });
    
    return issues;
  } catch (error) {
    console.error("Error getting issues: ", error);
    return [];
  }
}

// Get issues for heatmap
async function getIssuesForHeatmap() {
  try {
    const issuesSnap = await getDocs(collection(db, "issues"));
    const heatData = [];
    
    issuesSnap.forEach(docSnap => {
      const data = docSnap.data();
      if (data.lat && data.lng) {
        const intensity = (data.voteCount || 1) + (data.priority === 'high' ? 5 : data.priority === 'medium' ? 2 : 1);
        heatData.push([data.lat, data.lng, intensity]);
      }
    });
    
    return heatData;
  } catch (error) {
    console.error("Error getting issues for heatmap: ", error);
    return [];
  }
}

// Real-time listener for issues
function startRealtimeListener() {
  if (unsubscribe) {
    unsubscribe();
  }
  
  const q = query(collection(db, "issues"), orderBy("createdAt", "desc"));
  
  unsubscribe = onSnapshot(q, (snapshot) => {
    const issues = [];
    snapshot.forEach((doc) => {
      issues.push({ id: doc.id, ...doc.data() });
    });
    
    // Trigger update callbacks
    if (window.LocalLensMap && window.LocalLensMap.updateMapMarkers) {
      window.LocalLensMap.updateMapMarkers(issues);
    }
    
    if (window.LocalLensAdmin && window.LocalLensAdmin.updateAdminCharts) {
      window.LocalLensAdmin.updateAdminCharts(issues);
    }
  });
}

// Export Firebase functions
window.LocalLensFirebase = {
  auth,
  db,
  currentUser,
  signUp,
  signIn,
  signOutUser,
  submitIssue,
  updateIssueStatus,
  voteOnIssue,
  addComment,
  getAllIssues,
  getIssuesForHeatmap,
  startRealtimeListener
};
