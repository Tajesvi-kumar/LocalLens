// Admin functionality for LocalLens application

let adminAnalyticsUnsubscribe = null;
let analyticsData = {
  issues: [],
  totalIssues: 0,
  completedIssues: 0,
  pendingIssues: 0,
  categoryCounts: {},
  dateTrends: {}
};

// Initialize admin dashboard
function initAdminDashboard() {
  // Setup sidebar navigation
  setupSidebarNavigation();
  
  // Setup admin analytics if user is admin
  if (window.LocalLensFirebase && window.LocalLensFirebase.isAdmin()) {
    setupAdminAnalytics();
  }
  
  // Setup refresh button
  setupRefreshButton();
}

// Setup sidebar navigation
function setupSidebarNavigation() {
  const sidebarItems = document.querySelectorAll('.sidebar-item');
  const adminSections = document.querySelectorAll('.admin-section');
  
  sidebarItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Remove active class from all items
      sidebarItems.forEach(i => i.classList.remove('active'));
      
      // Add active class to clicked item
      item.classList.add('active');
      
      // Hide all sections
      adminSections.forEach(section => section.classList.add('hidden'));
      
      // Show selected section
      const sectionName = item.dataset.section;
      const targetSection = document.getElementById(`admin-${sectionName}`);
      if (targetSection) {
        targetSection.classList.remove('hidden');
      }
    });
  });
}

// Setup admin analytics
function setupAdminAnalytics() {
  if (!window.LocalLensFirebase || !window.LocalLensFirebase.db) {
    console.warn('Firebase not initialized, cannot setup admin analytics');
    return;
  }

  console.log('Setting up admin analytics subscription...');
  
  // Clean up any existing subscriptions
  if (adminAnalyticsUnsubscribe) {
    adminAnalyticsUnsubscribe();
  }
  
  // Subscribe to real-time updates from Firestore
  const db = window.LocalLensFirebase.db;
  const { collection, onSnapshot } = window.LocalLensFirebase.firestoreModules;
  
  const issuesRef = collection(db, "issues");
  adminAnalyticsUnsubscribe = onSnapshot(issuesRef, (snapshot) => {
    try {
      analyticsData.issues = [];
      snapshot.forEach((doc) => {
        analyticsData.issues.push({
          id: doc.id,
          ...doc.data()
        });
      });

      // Process data
      processAnalyticsData();
      
      // Wait for all prerequisites before loading charts/KPIs
      const checkAndLoad = () => {
        if (isReadyForCharts()) {
          // All conditions met - load KPIs and charts with delay
          setTimeout(() => {
            initializeAdminAnalytics(analyticsData.issues);
          }, 500);
        } else {
          // Not ready yet, check again after a short delay
          setTimeout(checkAndLoad, 200);
        }
      };
      
      // Start checking
      checkAndLoad();
    } catch (e) {
      console.error('Error in admin analytics subscription:', e);
    }
  }, (error) => {
    console.error('Error fetching issues for analytics:', error);
  });
}

// Check if all prerequisites are ready for loading charts/KPIs
function isReadyForCharts() {
  // Check if adminAnalytics container is visible
  const adminAnalytics = document.getElementById('admin-analytics');
  if (!adminAnalytics || adminAnalytics.classList.contains('hidden') || adminAnalytics.style.display === 'none') {
    return false;
  }
  
  // For admin analytics page, we don't need map or posts to be ready
  // Just check if the analytics container is visible
  return true;
}

// Initialize admin analytics with data
function initializeAdminAnalytics(issues) {
  // Update KPI cards
  updateKPICards();
  
  // Update charts
  if (window.LocalLensCharts) {
    window.LocalLensCharts.updateAdminCharts(issues);
  }
  
  // Render admin heatmap
  renderAdminHeatmap(issues);
}

// Process analytics data from issues
function processAnalyticsData() {
  const issues = analyticsData.issues;
  
  // Reset counters
  analyticsData.totalIssues = issues.length;
  analyticsData.completedIssues = 0;
  analyticsData.pendingIssues = 0;
  analyticsData.categoryCounts = {};
  analyticsData.dateTrends = {};

  issues.forEach(issue => {
    // Count completed vs pending
    const status = issue.status?.toLowerCase() || 'open';
    if (status === 'resolved' || status === 'completed' || status === 'closed') {
      analyticsData.completedIssues++;
    } else {
      analyticsData.pendingIssues++;
    }

    // Count by category
    const category = issue.category || 'Other';
    analyticsData.categoryCounts[category] = (analyticsData.categoryCounts[category] || 0) + 1;

    // Group by date (for trend analysis) - skip items with invalid dates
    let issueDate = null;
    
    // Try timestamp first
    if (issue.timestamp) {
      issueDate = window.LocalLensCharts ? window.LocalLensCharts.safeDate(issue.timestamp) : safeDate(issue.timestamp);
    }
    
    // Fallback to createdAt
    if (!issueDate && issue.createdAt) {
      issueDate = window.LocalLensCharts ? window.LocalLensCharts.safeDate(issue.createdAt) : safeDate(issue.createdAt);
    }
    
    // Skip items with null dates for date grouping
    if (!issueDate) {
      return; // Skip date processing for this issue, but already counted above
    }

    // Group by day (YYYY-MM-DD format)
    try {
      const dateKey = issueDate.toISOString().split('T')[0];
      analyticsData.dateTrends[dateKey] = (analyticsData.dateTrends[dateKey] || 0) + 1;
    } catch (e) {
      console.warn('Error processing date for issue:', issue.id, e);
    }
  });
}

// Safe date parsing function - prevents RangeError crashes
function safeDate(input) {
  if (!input) return null;
  
  // Handle Firestore timestamp objects
  if (input && typeof input.toDate === 'function') {
    try {
      const d = input.toDate();
      return isNaN(d.getTime()) ? null : d;
    } catch (e) {
      return null;
    }
  }
  
  // Handle Date objects
  if (input instanceof Date) {
    return isNaN(input.getTime()) ? null : input;
  }
  
  // Handle string/number dates - simplified version
  const d = new Date(input);
  return isNaN(d.getTime()) ? null : d;
}

// Update KPI cards with real data
function updateKPICards() {
  // Total Issues
  const kpiTotal = document.getElementById('kpiTotalIssues');
  if (kpiTotal) {
    kpiTotal.textContent = analyticsData.totalIssues;
  }

  // Completed Issues
  const kpiCompleted = document.getElementById('kpiCompletedIssues');
  if (kpiCompleted) {
    kpiCompleted.textContent = analyticsData.completedIssues;
  }

  // Pending Issues
  const kpiPending = document.getElementById('kpiPendingIssues');
  if (kpiPending) {
    kpiPending.textContent = analyticsData.pendingIssues;
  }

  // Most Common Category
  const kpiCategory = document.getElementById('kpiCommonCategory');
  if (kpiCategory) {
    const categories = analyticsData.categoryCounts;
    if (Object.keys(categories).length > 0) {
      const mostCommon = Object.entries(categories).reduce((a, b) => 
        categories[a[0]] > categories[b[0]] ? a : b
      );
      kpiCategory.textContent = mostCommon[0];
    } else {
      kpiCategory.textContent = '--';
    }
  }
}

// Render heatmap for admin analytics
function renderAdminHeatmap(issues) {
  try {
    // Check if L.heatLayer is available
    if (typeof L === 'undefined' || typeof L.heatLayer === 'undefined') {
      console.warn('L.heatLayer not available, skipping heatmap');
      return;
    }
    
    const chartHeatmap = document.getElementById('chartHeatmap');
    if (!chartHeatmap) {
      console.warn('chartHeatmap element not found');
      return;
    }
    
    // Clear previous content
    chartHeatmap.innerHTML = '';
    
    // Create a small map container for heatmap
    const heatmapMap = L.map(chartHeatmap).setView([12.9716, 77.5946], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(heatmapMap);
    
    // Prepare heat data from issues
    const heatData = [];
    if (issues && Array.isArray(issues)) {
      issues.forEach(issue => {
        if (issue.lat && issue.lng) {
          const intensity = (issue.voteCount || 1) + (issue.priority === 'high' ? 5 : issue.priority === 'medium' ? 2 : 1);
          heatData.push([issue.lat, issue.lng, intensity]);
        }
      });
    }
    
    if (heatData.length > 0) {
      L.heatLayer(heatData, {
        radius: 25,
        blur: 18,
        maxZoom: 17,
        minOpacity: 0.5,
        gradient: {0.2: '#43A047', 0.4: '#f59e0b', 0.7: '#e53935', 1.0: '#2563eb'}
      }).addTo(heatmapMap);
    } else {
      chartHeatmap.innerHTML = '<p style="color: var(--text-light); text-align: center; padding: 2rem;">No location data available for heatmap.</p>';
    }
  } catch (e) {
    console.warn('Heatmap failed, continuing without it.', e);
    const chartHeatmap = document.getElementById('chartHeatmap');
    if (chartHeatmap) {
      chartHeatmap.innerHTML = '<p style="color: var(--text-light); text-align: center; padding: 2rem;">Heatmap unavailable.</p>';
    }
  }
}

// Setup refresh button
function setupRefreshButton() {
  const refreshBtn = document.getElementById('refreshAnalytics');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      refreshBtn.disabled = true;
      refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
      refreshAdminAnalytics();
      setTimeout(() => {
        refreshBtn.disabled = false;
        refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh Analytics';
      }, 1000);
    });
  }
}

// Refresh analytics manually
function refreshAdminAnalytics() {
  if (!window.LocalLensFirebase || !window.LocalLensFirebase.db) {
    console.warn('Firebase not initialized, cannot refresh analytics');
    return;
  }
  
  // Force reload by calling setupAdminAnalytics again
  setupAdminAnalytics();
}

// Clean up admin analytics
function cleanupAdminAnalytics() {
  // Unsubscribe from Firestore
  if (adminAnalyticsUnsubscribe) {
    adminAnalyticsUnsubscribe();
    adminAnalyticsUnsubscribe = null;
  }

  // Destroy charts
  if (window.LocalLensCharts) {
    window.LocalLensCharts.destroyAllCharts();
  }

  // Reset analytics data
  analyticsData = {
    issues: [],
    totalIssues: 0,
    completedIssues: 0,
    pendingIssues: 0,
    categoryCounts: {},
    dateTrends: {}
  };
}

// Export admin functions
window.LocalLensAdmin = {
  initAdminDashboard,
  setupAdminAnalytics,
  refreshAdminAnalytics,
  cleanupAdminAnalytics,
  isReadyForCharts,
  initializeAdminAnalytics
};
