// Chart functionality for LocalLens application

let pieChart = null;
let barChart = null;
let lineChart = null;

// Chart colors
const chartColors = {
  primary: 'rgba(37, 99, 235, 0.8)',
  primaryBorder: 'rgba(37, 99, 235, 1)',
  secondary: 'rgba(16, 185, 129, 0.8)',
  secondaryBorder: 'rgba(16, 185, 129, 1)',
  accent: 'rgba(245, 158, 11, 0.8)',
  accentBorder: 'rgba(245, 158, 11, 1)',
  danger: 'rgba(239, 68, 68, 0.8)',
  dangerBorder: 'rgba(239, 68, 68, 1)',
  purple: 'rgba(139, 92, 246, 0.8)',
  purpleBorder: 'rgba(139, 92, 246, 1)',
  lightBlue: 'rgba(59, 130, 246, 0.8)',
  lightBlueBorder: 'rgba(59, 130, 246, 1)'
};

// Color palette for pie charts
const pieChartColors = [
  chartColors.primary,
  chartColors.secondary,
  chartColors.accent,
  chartColors.danger,
  chartColors.purple,
  chartColors.lightBlue
];

// Safe date parsing function - prevents RangeError crashes
function safeDate(input) {
  if (!input) return null;
  
  // Handle Firestore timestamp objects
  if (input && typeof input.toDate === 'function') {
    try {
      const d = input.toDate();
      return isNaN(d.getTime()) ? null : d;
    } catch (e) {
      return null;
    }
  }
  
  // Handle string dates
  if (typeof input === 'string') {
    try {
      const d = new Date(input);
      return isNaN(d.getTime()) ? null : d;
    } catch (e) {
      return null;
    }
  }
  
  // Handle Date objects
  if (input instanceof Date) {
    return isNaN(input.getTime()) ? null : input;
  }
  
  return null;
}

// Create or update pie chart
function updatePieChart(canvasId, data, labels) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;

  // Handle empty data
  if (labels.length === 0 || data.length === 0) {
    if (pieChart) {
      pieChart.destroy();
      pieChart = null;
    }
    return;
  }

  if (pieChart) {
    pieChart.data.labels = labels;
    pieChart.data.datasets[0].data = data;
    pieChart.update();
  } else {
    pieChart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: labels,
        datasets: [{
          label: 'Issues by Category',
          data: data,
          backgroundColor: pieChartColors.slice(0, labels.length),
          borderColor: pieChartColors.slice(0, labels.length).map(c => c.replace('0.8', '1')),
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 15,
              font: {
                size: 12
              }
            }
          },
          title: {
            display: false
          }
        }
      }
    });
  }
}

// Create or update bar chart
function updateBarChart(canvasId, data, labels) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;

  // Handle empty data
  if (labels.length === 0 || data.length === 0) {
    if (barChart) {
      barChart.destroy();
      barChart = null;
    }
    return;
  }

  if (barChart) {
    barChart.data.labels = labels;
    barChart.data.datasets[0].data = data;
    barChart.update();
  } else {
    barChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Number of Issues',
          data: data,
          backgroundColor: chartColors.primary,
          borderColor: chartColors.primaryBorder,
          borderWidth: 2,
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: false
          },
          title: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      }
    });
  }
}

// Create or update line chart
function updateLineChart(canvasId, data, labels) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;

  // Handle empty data
  if (labels.length === 0 || data.length === 0) {
    if (lineChart) {
      lineChart.destroy();
      lineChart = null;
    }
    return;
  }

  if (lineChart) {
    lineChart.data.labels = labels;
    lineChart.data.datasets[0].data = data;
    lineChart.update();
  } else {
    lineChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Issues Reported',
          data: data,
          borderColor: chartColors.secondaryBorder,
          backgroundColor: chartColors.secondary,
          borderWidth: 3,
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: false
          },
          title: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      }
    });
  }
}

// Process issues data for charts
function processIssuesData(issues) {
  const categoryCounts = {};
  const statusCounts = {};
  const dateTrends = {};

  issues.forEach(issue => {
    // Count by category
    const category = issue.category || 'other';
    categoryCounts[category] = (categoryCounts[category] || 0) + 1;

    // Count by status
    const status = issue.status || 'pending';
    statusCounts[status] = (statusCounts[status] || 0) + 1;

    // Count by date
    const date = safeDate(issue.createdAt);
    if (date) {
      const dateStr = date.toISOString().split('T')[0]; // YYYY-MM-DD
      dateTrends[dateStr] = (dateTrends[dateStr] || 0) + 1;
    }
  });

  return {
    categoryCounts,
    statusCounts,
    dateTrends
  };
}

// Get last 7 days for trend chart
function getLast7Days() {
  const dates = [];
  const today = new Date();
  
  for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    dates.push(date.toISOString().split('T')[0]);
  }
  
  return dates;
}

// Update all admin charts
function updateAdminCharts(issues) {
  const processed = processIssuesData(issues);
  
  // Update category pie chart
  const categoryLabels = Object.keys(processed.categoryCounts);
  const categoryData = Object.values(processed.categoryCounts);
  updatePieChart('chartCategory', categoryData, categoryLabels);
  
  // Update status bar chart
  const statusLabels = Object.keys(processed.statusCounts);
  const statusData = Object.values(processed.statusCounts);
  updateBarChart('chartStatus', statusData, statusLabels);
  
  // Update trend line chart
  const last7Days = getLast7Days();
  const trendData = last7Days.map(date => processed.dateTrends[date] || 0);
  const formattedLabels = last7Days.map(date => {
    const d = safeDate(date);
    if (!d) return date;
    return `${d.getMonth() + 1}/${d.getDate()}`;
  });
  updateLineChart('chartTrends', trendData, formattedLabels);
}

// Destroy all charts
function destroyAllCharts() {
  if (pieChart) {
    pieChart.destroy();
    pieChart = null;
  }
  if (barChart) {
    barChart.destroy();
    barChart = null;
  }
  if (lineChart) {
    lineChart.destroy();
    lineChart = null;
  }
}

// Export chart functions
window.LocalLensCharts = {
  updatePieChart,
  updateBarChart,
  updateLineChart,
  updateAdminCharts,
  destroyAllCharts,
  processIssuesData,
  safeDate
};
