// Map functionality for LocalLens application

let map;
let markers = [];
let nearbyHospitalsLayer;

// Initialize map
function initMap() {
  const mapEl = document.getElementById('map');
  if (!mapEl) {
    console.error('Map element not found');
    return;
  }

  // Create map instance
  map = L.map(mapEl).setView([12.9716, 77.5946], 13);
  window.map = map; // Store in window for global access

  // Add tile layer
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  // Initialize nearby hospitals layer
  nearbyHospitalsLayer = L.layerGroup().addTo(map);

  // Add hospitals control
  createHospitalsControl(map);

  // Wait for Firebase to initialize before loading markers
  setTimeout(() => {
    if (window.LocalLensFirebase && window.LocalLensFirebase.startRealtimeListener) {
      window.LocalLensFirebase.startRealtimeListener();
    }
  }, 1000);
}

// Get browser geolocation
function getUserLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation not supported'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      err => reject(err),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  });
}

// Create custom icon for issues
function createIssueIcon(status) {
  const colors = {
    pending: '#f59e0b',
    'in-progress': '#3b82f6',
    resolved: '#10b981',
    high_priority: '#ef4444'
  };
  
  return L.divIcon({
    className: 'custom-issue-marker',
    html: `<div style="background: ${colors[status] || '#f59e0b'}; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, -12]
  });
}

// Update map markers with issues data
function updateMapMarkers(issues) {
  // Clear existing markers
  markers.forEach(marker => map.removeLayer(marker));
  markers = [];

  // Add markers for each issue
  issues.forEach(issue => {
    if (issue.lat && issue.lng) {
      const marker = L.marker([issue.lat, issue.lng], {
        icon: createIssueIcon(issue.status)
      });

      // Create popup content
      const popupContent = `
        <div style="min-width: 200px;">
          <h4 style="margin: 0 0 8px 0; color: #1f2937;">${issue.title}</h4>
          <p style="margin: 0 0 8px 0; color: #6b7280; font-size: 14px;">${issue.description}</p>
          <div style="display: flex; gap: 8px; margin-bottom: 8px;">
            <span style="background: #f3f4f6; padding: 2px 8px; border-radius: 4px; font-size: 12px;">${issue.category}</span>
            <span style="background: ${window.LocalLensCore ? window.LocalLensCore.getStatusColor(issue.status) : '#f3f4f6'}; color: ${window.LocalLensCore ? window.LocalLensCore.getStatusTextColor(issue.status) : '#374151'}; padding: 2px 8px; border-radius: 4px; font-size: 12px;">${issue.status}</span>
          </div>
          <div style="font-size: 12px; color: #9ca3af;">
            ${window.LocalLensCore ? window.LocalLensCore.formatDate(issue.createdAt) : 'N/A'}
          </div>
          ${issue.voteCount ? `<div style="margin-top: 8px; font-size: 14px;">👍 ${issue.voteCount} votes</div>` : ''}
        </div>
      `;

      marker.bindPopup(popupContent);
      marker.addTo(map);
      markers.push(marker);
    }
  });

  // Fit map to show all markers if there are any
  if (markers.length > 0) {
    const group = new L.featureGroup(markers);
    map.fitBounds(group.getBounds().pad(0.1));
  }
}

// Fetch nearby hospitals/clinics from Overpass and render markers
async function loadNearbyHospitals(mapInstance, lat, lng, radiusMeters = 3000) {
  const query = `
    [out:json][timeout:25];
    (
      node["amenity"~"hospital|clinic"](around:${radiusMeters},${lat},${lng});
      way["amenity"~"hospital|clinic"](around:${radiusMeters},${lat},${lng});
      relation["amenity"~"hospital|clinic"](around:${radiusMeters},${lat},${lng});
    );
    out center tags;
  `;

  // Clear previous results
  nearbyHospitalsLayer.clearLayers();

  let response;
  try {
    response = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: new URLSearchParams({ data: query }).toString()
    });
  } catch (e) {
    console.error('Network error calling Overpass:', e);
    alert('Unable to reach hospital data service. Please try again later.');
    return 0;
  }

  if (!response.ok) {
    console.error('Overpass API error:', response.status, response.statusText);
    alert('Hospital data service returned an error. Please try again later.');
    return 0;
  }

  const data = await response.json();
  const elements = Array.isArray(data.elements) ? data.elements : [];

  const hospitalIcon = L.icon({
    iconUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-icon-red.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    shadowSize: [41, 41]
  });

  const boundsPoints = [];

  elements.forEach(el => {
    const center = el.type === 'node' ? { lat: el.lat, lng: el.lon } : (el.center || {});
    if (!center.lat || !center.lng) return;
    const name = (el.tags && el.tags.name) || 'Unnamed';
    const type = (el.tags && el.tags.amenity) || 'hospital';
    const address = [
      el.tags && el.tags.addr_housenumber,
      el.tags && el.tags.addr_street,
      el.tags && el.tags.addr_city
    ].filter(Boolean).join(', ');
    const phone = (el.tags && (el.tags.phone || el.tags.contact_phone)) || '';
    const website = (el.tags && (el.tags.website || el.tags.contact_website)) || '';

    const m = L.marker([center.lat, center.lng], { icon: hospitalIcon });
    m.bindPopup(
      `<strong>${name}</strong><br/>` +
      `Type: ${type}<br/>` +
      (address ? `Address: ${address}<br/>` : '') +
      (phone ? `Phone: ${phone}<br/>` : '') +
      (website ? `<a href="${website}" target="_blank">Website</a>` : '')
    );
    m.addTo(nearbyHospitalsLayer);
    boundsPoints.push([center.lat, center.lng]);
  });

  if (boundsPoints.length > 0) {
    const b = L.latLngBounds(boundsPoints);
    if (b.isValid()) mapInstance.fitBounds(b.pad(0.1));
  } else {
    alert('No nearby hospitals found within the selected radius.');
  }

  return elements.length;
}

// Leaflet control to trigger hospital search
function createHospitalsControl(mapInstance) {
  const HospitalsControl = L.Control.extend({
    options: { position: 'topleft' },
    onAdd: function() {
      const container = L.DomUtil.create('div', 'leaflet-bar');
      const btn = L.DomUtil.create('a', '', container);
      btn.href = '#';
      btn.title = 'Find Nearby Hospitals';
      btn.innerHTML = '🏥';
      btn.style.lineHeight = '26px';
      btn.style.textAlign = 'center';

      L.DomEvent.on(btn, 'click', L.DomEvent.stopPropagation)
                .on(btn, 'click', L.DomEvent.preventDefault)
                .on(btn, 'click', async () => {
                  try {
                    const { lat, lng } = await getUserLocation();
                    L.marker([lat, lng]).addTo(mapInstance).bindPopup('You are here').openPopup();
                    await loadNearbyHospitals(mapInstance, lat, lng, 3000);
                  } catch (e) {
                    // Fallback to map center if geolocation denied
                    const center = mapInstance.getCenter();
                    await loadNearbyHospitals(mapInstance, center.lat, center.lng, 3000);
                  }
                });

      return container;
    }
  });

  mapInstance.addControl(new HospitalsControl());
}

// Heatmap rendering
async function renderHeatmap() {
  const heatmapEl = document.getElementById('heatmap');
  if (!heatmapEl) return;

  // Check if Firebase is initialized
  if (!window.LocalLensFirebase || !window.LocalLensFirebase.db) {
    console.warn('Firebase not initialized, skipping heatmap');
    return;
  }

  // Remove any previous map instance
  if (window.heatmapInstance) {
    window.heatmapInstance.remove();
    window.heatmapInstance = null;
  }

  // Center on city
  const heatmapMap = L.map(heatmapEl).setView([12.9716, 77.5946], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(heatmapMap);

  // Fetch issue locations from Firestore
  try {
    const heatData = await window.LocalLensFirebase.getIssuesForHeatmap();
    
    if (heatData.length > 0) {
      L.heatLayer(heatData, {
        radius: 25,
        blur: 18,
        maxZoom: 17,
        minOpacity: 0.5,
        gradient: {0.2: '#43A047', 0.4: '#f59e0b', 0.7: '#e53935', 1.0: '#2563eb'}
      }).addTo(heatmapMap);

      // Highlight each issue spot with a red circle marker
      heatData.forEach(([lat, lng, intensity]) => {
        L.circleMarker([lat, lng], {
          color: '#e53935',
          fillColor: '#e53935',
          fillOpacity: 0.9,
          radius: 10,
          weight: 2
        }).addTo(heatmapMap);
      });
    }
  } catch (error) {
    console.error('Error loading heatmap data:', error);
  }

  window.heatmapInstance = heatmapMap;
}

// Initialize map when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  initMap();
  // Wait for Firebase to initialize before rendering heatmap
  setTimeout(renderHeatmap, 1000);
});

// Export map functions
window.LocalLensMap = {
  initMap,
  updateMapMarkers,
  loadNearbyHospitals,
  renderHeatmap,
  getUserLocation
};
